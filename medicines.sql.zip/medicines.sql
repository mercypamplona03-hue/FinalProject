-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql309.byetcluster.com
-- Generation Time: Nov 13, 2026 at 06:18 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43431357_pharmacy_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `medicine_name` varchar(150) NOT NULL,
  `generic_name` varchar(150) NOT NULL,
  `category` varchar(100) NOT NULL,
  `batch_no` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `unit_price` decimal(10,2) NOT NULL,
  `expiry_date` date NOT NULL,
  `supplier` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`id`, `medicine_name`, `generic_name`, `category`, `batch_no`, `quantity`, `unit_price`, `expiry_date`, `supplier`, `created_at`) VALUES
(1, 'Biogesic', 'Paracetamol', 'Pain Reliever', 'BIO-001', 50, '7.00', '2026-12-13', 'Unilab', '2026-11-13 10:22:47'),
(2, 'Amoxicillin', 'Amoxicillin', 'Antibiotic', 'AMO-002', 15, '12.00', '2027-08-15', 'MedSource', '2026-11-13 10:22:47'),
(3, 'Neozep', 'Phenylephrine Combination', 'Cold Medicine', 'NEO-003', 8, '8.50', '2026-05-20', 'Unilab', '2026-11-13 10:22:47'),
(4, 'Bioflu', 'Phenylephrine Combination', 'Cold Medicine', 'BIO-004', 50, '9.00', '2028-01-15', 'Unilab', '2026-11-13 10:22:47'),
(5, 'Cetirizine', 'Cetirizine', 'Antihistamine', 'CET-005', 5, '6.00', '2027-09-10', 'Generic Pharma', '2026-11-13 10:22:47'),
(7, 'loperamied', 'salbutamol', 'Other', 'CET-004', 80, '2.00', '2028-02-25', 'Mercury Drug', '2026-11-13 11:17:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
